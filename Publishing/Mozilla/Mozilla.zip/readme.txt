Instructions:
To build an exact copy, execute the commands:

npm install
gulp build


Operating System: Windows 10 Pro

Requirements: NodeJS 12.4.0 (Latest) and NPM 6.9.0 (Latest).

You can view the same source code on https://github.com/VoidlessSeven7/Steam-Little-Toolkit-Browser-Extension